SELECT * FROM friends;

INSERT INTO friends (firstname, lastname, email, created_at, updated_at)
VALUES ("Steve", "Kerr", "Bulls@Chicago.Mail.Com", now(), now());

INSERT INTO friends (firstname, lastname, email, created_at, updated_at)
VALUES ("Luke", "Longley", "Bulls@Chicago.Mail.Com", now(),now());