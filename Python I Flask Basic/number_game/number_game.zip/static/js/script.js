alert("Hello, please place your bets... Good Luck!")
