alert("Get POST'ed")
