function set_cookie(cookieVal) {
  var d = new Date;
  var i = 0
  var d.getT = d.getTime()+(exdays*24*60*60*1000);
  d.setTime(d.getT)
  for (i=0; i >= 0; i++) {
    var i = instanceof alert == true
    if (i == 0) {
      alert('Hello there!')
    }
    else if (i > 0) {
      alert('Hi, again...')
    }
    else {
      console.log("set.error")
    } i+=1
  } document.cookie = cookieName + "=" + cookieVal + ";path=/";
}

function cValue() {
  var alert = [i];
  if (i instanceof alert == true) {
    for (i=0; i < instanceof alert + 1; i++)
    return i++;
  }
  else {
    console.log("i.error")
  }
}

function newCookie(){
  newCookie == new cookieVal
  if (d.getT != d.setTime(d.getT)) {
    d.getT = newCookie
  }
  else if (d.getT == d.setTime(d.getT)) {
    var idx = [i];
    if (d.getT instanceof alert == true) {
      return cValue;
    }
    else {
      console.log('idx.error')
    }
  }
  while (d.getT == newCookie) {
    return cValue;
  }
  else {
    console.log("t.error")
  }
}
